import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sms_autofill/sms_autofill.dart';
import 'dart:async';
import 'dart:math';

// Hàm tạo mã OTP giả 6 chữ số ngẫu nhiên
String generateRandomOtp() {
  final random = Random();
  return (random.nextInt(900000) + 100000).toString(); // Tạo mã OTP 6 chữ số
}

class SmsAutoFillExample extends StatefulWidget {
  @override
  _SmsAutoFillExampleState createState() => _SmsAutoFillExampleState();
}

class _SmsAutoFillExampleState extends State<SmsAutoFillExample>
    with CodeAutoFill {
  String? _code;
  String? _appSignature;
  late String _fakeOtp; // Mã OTP giả
  final TextEditingController _otpController =
      TextEditingController(); // Controller cho PinFieldAutoFill
  List<String> _otpSuggestions = []; // Danh sách các đề xuất mã OTP

  @override
  void initState() {
    super.initState();
    _fakeOtp = generateRandomOtp(); // Tạo mã OTP giả
    _getAppSignature();
    listenForCode();
    _simulateFakeOtp(); // Giả lập điền mã OTP
  }

  Future<void> _getAppSignature() async {
    _appSignature = await SmsAutoFill().getAppSignature;
    print('App Signature: $_appSignature');
  }

  // Hàm giả lập điền mã OTP vào PinFieldAutoFill
  void _simulateFakeOtp() {
    Future.delayed(Duration(seconds: 3), () {
      setState(() {
        _code = _fakeOtp; // Điền mã OTP giả vào biến
        _otpController.text = _fakeOtp; // Gán mã OTP vào controller
      });
      print('Fake OTP: $_fakeOtp');
    });
  }

  // Hàm tạo danh sách đề xuất mã OTP
  void _generateOtpSuggestions() {
    List<String> suggestions = [];
    for (int i = 0; i < 5; i++) {
      suggestions.add(generateRandomOtp()); // Tạo 5 mã OTP ngẫu nhiên
    }
    setState(() {
      _otpSuggestions = suggestions;
    });
  }

  @override
  void dispose() {
    cancel(); // Hủy lắng nghe SMS khi không cần
    _otpController.dispose(); // Hủy controller khi không cần
    super.dispose();
  }

  @override
  void codeUpdated() {
    setState(() {
      _code = code;
    });
  }

  // Hàm hiển thị thanh thông báo (SnackBar)
  void _showOtpNotification() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Please enter the OTP: $_fakeOtp'),
        action: SnackBarAction(
          label: 'Enter OTP',
          onPressed: () {
            // Mở giao diện để người dùng điền OTP
            _otpController.text = _fakeOtp;
            print('OTP entered: $_fakeOtp');
          },
        ),
        duration: Duration(seconds: 5),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('SMS AutoFill Example'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // TextField với danh sách đề xuất
            TextField(
              controller: _otpController,
              decoration: InputDecoration(
                labelText: "Enter OTP",
                suffixIcon: IconButton(
                  icon: Icon(Icons.search),
                  onPressed:
                      _generateOtpSuggestions, // Tạo danh sách đề xuất khi nhấn vào biểu tượng tìm kiếm
                ),
              ),
            ),
            // Hiển thị danh sách các đề xuất dưới TextField
            if (_otpSuggestions.isNotEmpty)
              Container(
                height: 100,
                child: ListView.builder(
                  itemCount: _otpSuggestions.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      title: Text(_otpSuggestions[index]),
                      onTap: () {
                        setState(() {
                          _otpController.text = _otpSuggestions[
                              index]; // Tự động điền mã OTP khi chọn đề xuất
                        });
                      },
                    );
                  },
                ),
              ),
            SizedBox(height: 20),
            Text(
              'App Signature: $_appSignature',
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                print('Code: $_code');
                _showOtpNotification(); // Hiển thị thanh thông báo khi bấm nút
              },
              child: Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}
